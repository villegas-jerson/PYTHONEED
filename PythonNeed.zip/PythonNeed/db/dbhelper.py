from sqlite3 import connect, Row

database = "db/school.db"


def getprocess(sql: str, vals: list) -> list:
    conn = connect(database)
    conn.row_factory = Row
    cursor = conn.cursor()
    cursor.execute(sql, vals)
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data



def postprocess(sql: str, vals: list) -> bool:
    try:
        conn = connect(database)
        cursor = conn.cursor()
        cursor.execute(sql, vals)
        conn.commit()
    except Exception as e:
        print(f"Error: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

    return cursor.rowcount > 0




def getall(table: str) -> list:
    sql = f"SELECT * FROM {table}"
    return getprocess(sql, [])



def getrecord(table: str, **kwargs) -> list:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    conditions = [f"{key}=?" for key in keys]
    condition_str = " AND ".join(conditions)

    sql = f"SELECT * FROM {table} WHERE {condition_str}"
    return getprocess(sql, vals)



def addrecord(table: str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    placeholders = ",".join(["?"] * len(keys))
    fields = ",".join(keys)

    sql = f"INSERT INTO {table} ({fields}) VALUES ({placeholders})"
    return postprocess(sql, vals)



def deleterecord(table: str, **kwargs) -> bool:
    keys = list(kwargs.keys())
    vals = list(kwargs.values())

    conditions = [f"{key}=?" for key in keys]
    condition_str = " AND ".join(conditions)

    sql = f"DELETE FROM {table} WHERE {condition_str}"
    return postprocess(sql, vals)



def updaterecord(table: str, where: dict, updates: dict) -> bool:
    keys = list(updates.keys())
    vals = list(updates.values())

    set_parts = [f"{field}=?" for field in keys]
    set_clause = ", ".join(set_parts)

    where_key = list(where.keys())[0]
    where_val = list(where.values())[0]

    sql = f"UPDATE {table} SET {set_clause} WHERE {where_key} = ?"

    final_vals = vals + [where_val]
    return postprocess(sql, final_vals)

